import { BrowserRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom'
import { AnimatePresence }         from 'framer-motion'
import { AppProvider }             from '@/context/AppContext'
import { StudyProgressProvider }   from '@/context/StudyProgressContext'
import { ToastProvider }           from '@/context/ToastContext'
import LevelWatcher                from '@/components/LevelWatcher'
import Layout                      from '@/components/layout/Layout'

/* Pages */
import Home      from '@/pages/Home/Home'
import Subjects  from '@/pages/Subjects/Subjects'
import Chapter   from '@/pages/Chapter/Chapter'
import Analytics from '@/pages/Analytics/Analytics'
import Profile   from '@/pages/Profile/Profile'
import Settings  from '@/pages/Settings/Settings'

/**
 * AnimatedRoutes — keyed on pathname so AnimatePresence detects
 * route changes and plays PageTransition exit → enter.
 */
function AnimatedRoutes() {
  const location = useLocation()
  return (
    <AnimatePresence mode="wait" initial={false}>
      <Routes location={location} key={location.pathname}>
        <Route path="/"             element={<Home />}      />
        <Route path="/subjects"     element={<Subjects />}  />
        <Route path="/subjects/:id" element={<Chapter />}   />
        <Route path="/analytics"   element={<Analytics />} />
        <Route path="/profile"      element={<Profile />}   />
        <Route path="/settings"     element={<Settings />}  />
        <Route path="*"             element={<Navigate to="/" replace />} />
      </Routes>
    </AnimatePresence>
  )
}

/**
 * Provider hierarchy (outer → inner):
 *
 *   AppProvider            User + XP + localStorage sync
 *   StudyProgressProvider  Lecture completion + localStorage sync
 *   ToastProvider          Toast notifications
 *   LevelWatcher           Fires level-up toast on user.level change
 *   BrowserRouter          Routing
 *   Layout                 App shell
 *   AnimatedRoutes         Page switching
 */
export default function App() {
  return (
    <AppProvider>
      <StudyProgressProvider>
        <ToastProvider>
          <LevelWatcher />
          <BrowserRouter>
            <Layout>
              <AnimatedRoutes />
            </Layout>
          </BrowserRouter>
        </ToastProvider>
      </StudyProgressProvider>
    </AppProvider>
  )
}
