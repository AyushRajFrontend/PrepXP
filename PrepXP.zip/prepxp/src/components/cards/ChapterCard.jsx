import { useCallback }                      from 'react'
import { motion, AnimatePresence }          from 'framer-motion'
import {
  CheckCircle2, Circle,
  Clock, ChevronDown,
}                                           from 'lucide-react'
import GlassCard                            from '@/components/ui/GlassCard'
import ProgressBar                          from '@/components/ui/ProgressBar'
import { useStudyProgress }                 from '@/context/StudyProgressContext'
import { useToast }                         from '@/context/ToastContext'
import { useApp }                           from '@/context/AppContext'
import { cn }                               from '@/utils/cn'

/**
 * ChapterCard — Expandable chapter card with interactive lecture list.
 *
 * Changes from Phase 2:
 *   • LectureRow reads done-state from StudyProgressContext (not static data)
 *   • Tapping a pending lecture marks it done, awards XP + coins, fires toast
 *   • CheckCircle2 morphs in with a spring animation when marked done
 *   • Progress bar reflects live done count from context
 *
 * Props:
 *   chapter       — chapter object from src/data/chapters.js
 *   subjectColor  — 'physics' | 'chemistry' | 'math'
 *   isExpanded    — controlled from Chapter.jsx (one card open at a time)
 *   onToggle      — () => void
 */

/* ── Chapter status display config ── */
const STATUS_CONFIG = {
  'completed':   { icon: CheckCircle2, iconClass: 'text-success', badge: 'bg-success/10 text-success border-success/20',   label: 'Done'        },
  'in-progress': { icon: Clock,        iconClass: 'text-purple',  badge: 'bg-purple/10  text-purple  border-purple/20',    label: 'In Progress' },
  'not-started': { icon: Circle,       iconClass: 'text-dim',     badge: 'bg-white/[0.04] text-dim  border-white/[0.06]', label: 'Not Started' },
}


/* ════════════════════════════════════════
   LECTURE ROW — interactive
   ════════════════════════════════════════ */
function LectureRow({ lecture, onMarkDone }) {
  const { isLectureDone } = useStudyProgress()
  const done = isLectureDone(lecture.id)

  return (
    <motion.div
      className={cn(
        'flex items-center gap-3 py-2.5',
        'border-b border-white/[0.04] last:border-0',
        !done && 'cursor-pointer active:bg-white/[0.02] rounded-lg',
      )}
      onClick={!done ? () => onMarkDone(lecture) : undefined}
      whileTap={!done ? { scale: 0.98, x: 2 } : {}}
      transition={{ duration: 0.1 }}
    >
      {/* ── Status icon with animated morph ── */}
      <div className="w-[15px] h-[15px] flex-shrink-0 relative">
        <AnimatePresence mode="wait" initial={false}>
          {done ? (
            /* Done — spring-pop checkmark */
            <motion.div
              key="done"
              className="absolute inset-0"
              initial={{ scale: 0, rotate: -30 }}
              animate={{ scale: 1, rotate: 0   }}
              transition={{ type: 'spring', stiffness: 500, damping: 26 }}
            >
              <CheckCircle2 size={15} className="text-success" />
            </motion.div>
          ) : (
            /* Pending — static circle */
            <motion.div
              key="pending"
              className="absolute inset-0"
              initial={{ scale: 1, opacity: 0.9 }}
              animate={{ scale: 1, opacity: 1   }}
            >
              <Circle size={15} className="text-dim" />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* ── Lecture number + title ── */}
      <div className="flex-1 min-w-0 flex items-baseline gap-1.5">
        <span className="font-mono text-[10px] text-dim flex-shrink-0 leading-none">
          L{lecture.number}
        </span>
        <span className={cn(
          'text-[13px] font-medium truncate leading-snug',
          'transition-colors duration-300',
          done ? 'text-mist' : 'text-frost',
        )}>
          {lecture.title}
        </span>
      </div>

      {/* ── Duration ── */}
      <span className="font-mono text-[10.5px] text-dim flex-shrink-0">
        {lecture.duration}m
      </span>
    </motion.div>
  )
}


/* ════════════════════════════════════════
   CHAPTER CARD
   ════════════════════════════════════════ */
export default function ChapterCard({
  chapter,
  subjectColor,
  isExpanded,
  onToggle,
}) {
  const {
    number,
    name,
    status,
    totalLectures,
    lectures = [],
  } = chapter

  /* ── Hooks ── */
  const { countDone, markLectureDone } = useStudyProgress()
  const { toast }                       = useToast()
  const { addXp, addCoins }            = useApp()

  /* Live done count from context (overrides static data) */
  const doneLectures = countDone(lectures)
  const pct          = totalLectures > 0
    ? Math.round((doneLectures / totalLectures) * 100)
    : 0

  const cfg        = STATUS_CONFIG[status] ?? STATUS_CONFIG['not-started']
  const StatusIcon = cfg.icon
  const hasLectures = lectures.length > 0

  /* ── Lecture mark-done handler ── */
  const handleLectureTap = useCallback((lecture) => {
    const wasNew = markLectureDone(lecture.id)
    if (!wasNew) return   /* Already done — ignore */

    /* Award XP and coins */
    addXp(25)
    addCoins(5)

    /* Show toast */
    toast({
      icon:    '✅',
      title:   'Lecture Complete!',
      message: lecture.title,
      xp:      25,
      duration: 2500,
    })
  }, [markLectureDone, addXp, addCoins, toast])


  return (
    <GlassCard noPadding className="overflow-hidden">

      {/* ── Tappable header ── */}
      <button
        className={cn(
          'w-full flex items-center gap-3 px-4 py-3.5 text-left',
          'transition-colors duration-150 active:bg-white/[0.025]',
        )}
        onClick={onToggle}
        aria-expanded={isExpanded}
      >
        {/* Status icon */}
        <StatusIcon
          size={18}
          className={cn(cfg.iconClass, 'flex-shrink-0 mt-px')}
        />

        {/* Chapter name + live progress bar */}
        <div className="flex-1 min-w-0">
          <div className="flex items-baseline gap-2 mb-2">
            <span className="font-mono text-[10px] text-dim flex-shrink-0">
              {String(number).padStart(2, '0')}
            </span>
            <span className="text-[14px] font-semibold text-frost truncate">
              {name}
            </span>
          </div>
          <ProgressBar
            value={pct}
            color={subjectColor}
            size="xs"
            animated
            showGlow={false}
            showShimmer={false}
            delay={0}
          />
        </div>

        {/* Lecture count + expand chevron */}
        <div className="flex flex-col items-end gap-1.5 flex-shrink-0 ml-2">
          <span className="font-mono text-[11px] text-mist">
            {doneLectures}/{totalLectures}
          </span>
          {hasLectures && (
            <motion.div
              animate={{ rotate: isExpanded ? 180 : 0 }}
              transition={{ duration: 0.22, ease: [0.4, 0, 0.2, 1] }}
            >
              <ChevronDown size={14} className="text-dim" />
            </motion.div>
          )}
        </div>
      </button>

      {/* ── Expandable lecture list ── */}
      <AnimatePresence initial={false}>
        {isExpanded && hasLectures && (
          <motion.section
            key="lectures"
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{    height: 0, opacity: 0 }}
            transition={{ duration: 0.28, ease: [0.4, 0, 0.2, 1] }}
            className="overflow-hidden"
          >
            <div className="mx-4 border-t border-white/[0.06]" />

            <div className="px-4 pb-2 pt-1">
              {/* Status badge + count */}
              <div className="flex items-center justify-between py-2 mb-1">
                <span className={cn(
                  'text-[10px] font-bold uppercase tracking-widest',
                  'px-2.5 py-1 rounded-full border',
                  cfg.badge,
                )}>
                  {cfg.label}
                </span>
                <span className="text-[11px] text-mist">
                  <span className="text-frost font-semibold">{doneLectures}</span>
                  /{totalLectures} lectures
                </span>
              </div>

              {/* Lecture rows */}
              {lectures.map(lecture => (
                <LectureRow
                  key={lecture.id}
                  lecture={lecture}
                  onMarkDone={handleLectureTap}
                />
              ))}
            </div>
          </motion.section>
        )}
      </AnimatePresence>

    </GlassCard>
  )
}
