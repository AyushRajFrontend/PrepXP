import { motion }                             from 'framer-motion'
import { Timer, BookMarked, Flame, Trophy }  from 'lucide-react'
import GlassCard                             from '@/components/ui/GlassCard'
import { cn }                                from '@/utils/cn'

/**
 * StatsCard — 2×2 quick-stats grid on the Home dashboard.
 *
 * Displays four key metrics in a compact grid:
 *   Today's Study Time · Total Lectures
 *   Day Streak         · Global Rank
 *
 * Props:
 *   user — from AppContext (streak, rank, daysActive)
 *
 * Note: studyHours and totalLectures are hardcoded as demo
 *       values until the study timer is implemented.
 */

/* ── Individual stat cell ── */
function StatCell({ icon: Icon, iconColor, value, label, delay }) {
  return (
    <motion.div
      className="flex flex-col gap-1.5 p-3
                 bg-white/[0.03] rounded-xl border border-white/[0.05]"
      initial={{ opacity: 0, scale: 0.9 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true, margin: '-20px' }}
      transition={{ duration: 0.35, ease: [0.34, 1.56, 0.64, 1], delay }}
    >
      {/* Icon */}
      <div className={cn('w-7 h-7 rounded-lg flex items-center justify-center', iconColor)}>
        <Icon size={14} strokeWidth={2} />
      </div>

      {/* Value */}
      <span className="font-mono font-bold text-[20px] text-frost leading-none">
        {value}
      </span>

      {/* Label */}
      <span className="text-[10px] text-mist leading-tight">{label}</span>
    </motion.div>
  )
}

export default function StatsCard({ user }) {
  const {
    streak     = 0,
    rank       = '--',
  } = user

  const STATS = [
    {
      icon:      Timer,
      iconColor: 'bg-purple/10 text-purple',
      value:     '6h 14m',
      label:     "Today's Study",
      delay:     0.05,
    },
    {
      icon:      BookMarked,
      iconColor: 'bg-cyan/10 text-cyan',
      value:     '312',
      label:     'Lectures Done',
      delay:     0.10,
    },
    {
      icon:      Flame,
      iconColor: 'bg-streak/10 text-streak',
      value:     `${streak}d`,
      label:     'Study Streak',
      delay:     0.15,
    },
    {
      icon:      Trophy,
      iconColor: 'bg-xp/10 text-xp',
      value:     `#${rank}`,
      label:     'Global Rank',
      delay:     0.20,
    },
  ]

  return (
    <GlassCard noPadding className="p-4">
      <div className="grid grid-cols-2 gap-2.5">
        {STATS.map(stat => (
          <StatCell key={stat.label} {...stat} />
        ))}
      </div>
    </GlassCard>
  )
}
