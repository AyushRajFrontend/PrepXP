import { PieChart, Pie, Cell }       from 'recharts'
import { SUBJECTS, OVERALL_PROGRESS } from '@/data/subjects'

/**
 * SubjectDonut — Subject completion breakdown donut chart.
 *
 * Fixed-size (140 × 140 px) donut centered in its container.
 * The overall percentage is rendered as an absolute-positioned
 * overlay in the donut's hole.
 *
 * Uses hardcoded hex colors (matching CSS variable values)
 * because SVG fill attributes don't resolve CSS custom properties.
 *
 * Renders a custom legend below the chart with subject name + %.
 */

/* Hex colors matching --color-physics / chemistry / math */
const CHART_COLORS = {
  physics:     '#38BDF8',
  chemistry:   '#34D399',
  mathematics: '#A78BFA',
}

export default function SubjectDonut() {
  const pieData = SUBJECTS.map(s => ({
    name:  s.name,
    value: s.progress,
    color: CHART_COLORS[s.id] ?? '#7C3AED',
  }))

  return (
    <div className="flex flex-col items-center">

      {/* ── Donut chart with center overlay ── */}
      <div className="relative w-[140px] h-[140px] flex-shrink-0">
        <PieChart width={140} height={140}>
          <Pie
            data={pieData}
            cx={70}           /* 140 / 2 */
            cy={70}
            innerRadius={44}
            outerRadius={62}
            dataKey="value"
            paddingAngle={4}
            startAngle={90}
            endAngle={-270}   /* clockwise from top */
            strokeWidth={0}
          >
            {pieData.map((entry, i) => (
              <Cell key={i} fill={entry.color} />
            ))}
          </Pie>
        </PieChart>

        {/* Center label — absolute overlay */}
        <div className="absolute inset-0 flex flex-col items-center justify-center
                        pointer-events-none">
          <span className="font-mono font-bold text-[20px] text-frost leading-none">
            {OVERALL_PROGRESS}%
          </span>
          <span className="text-[10px] text-mist mt-0.5">overall</span>
        </div>
      </div>

      {/* ── Legend ── */}
      <div className="w-full space-y-2 mt-3">
        {SUBJECTS.map(subject => (
          <div key={subject.id} className="flex items-center gap-2">
            {/* Color dot */}
            <div
              className="w-[7px] h-[7px] rounded-full flex-shrink-0"
              style={{ background: CHART_COLORS[subject.id] }}
            />

            {/* Subject name */}
            <span className="text-[11.5px] text-mist flex-1 leading-none">
              {subject.name}
            </span>

            {/* Percentage */}
            <span className="font-mono text-[11.5px] text-frost font-semibold leading-none">
              {subject.progress}%
            </span>
          </div>
        ))}
      </div>

    </div>
  )
}
