import {
  createContext, useContext,
  useReducer, useCallback,
  useEffect,
} from 'react'
import { storageGet, storageSet, storageClear, KEYS } from '@/services/storage'

/**
 * AppContext — Global user state with localStorage persistence.
 *
 * Responsibilities:
 *   - User profile (name, level, XP, coins, streak, rank)
 *   - XP accumulation with automatic level-up detection
 *   - Persist to localStorage on every state change
 *   - Expose addXp / addCoins / reset action creators
 *
 * XP formula:
 *   xpToNext = currentLevel × 400 + 200
 *   Level 12 → 12×400+200 = 5000 XP needed ✓
 *
 * Level-up side effect (toast) is handled by <LevelWatcher>
 * so AppContext stays UI-agnostic.
 */

/* ─── XP formula ─── */
export function xpForLevel(level) {
  return level * 400 + 200
}

/* ─── Seed user (shown on first run / after reset) ─── */
const DEFAULT_USER = {
  id:         'usr_local_01',
  name:       'Ayush Raj',
  avatar:     null,
  level:      12,
  xp:         4820,
  xpToNext:   xpForLevel(12),   /* 5000 */
  streak:     7,
  coins:      320,
  rank:       23,
  daysActive: 47,
  joinedAt:   '2026-06-20',
}

/* Hydrate from localStorage, fall back to seed */
function loadUser() {
  return storageGet(KEYS.USER) ?? DEFAULT_USER
}

/* ─── Action types ─── */
export const ACTIONS = {
  ADD_XP:        'ADD_XP',
  ADD_COINS:     'ADD_COINS',
  UPDATE_STREAK: 'UPDATE_STREAK',
  RESET:         'RESET',
}

/* ─── Reducer ─── */
function appReducer(state, action) {
  switch (action.type) {

    case ACTIONS.ADD_XP: {
      let { xp, xpToNext, level, coins } = state.user
      xp += action.payload

      /*
       * Level-up loop — handles gaining multiple levels in
       * one XP burst (e.g. from a chapter completion bonus).
       */
      while (xp >= xpToNext) {
        xp      -= xpToNext
        level   += 1
        coins   += 50                   /* Level-up coin bonus */
        xpToNext = xpForLevel(level)
      }

      return {
        ...state,
        user: { ...state.user, xp, xpToNext, level, coins },
      }
    }

    case ACTIONS.ADD_COINS:
      return {
        ...state,
        user: {
          ...state.user,
          coins: state.user.coins + action.payload,
        },
      }

    case ACTIONS.UPDATE_STREAK:
      return {
        ...state,
        user: { ...state.user, streak: action.payload },
      }

    case ACTIONS.RESET:
      return { user: { ...DEFAULT_USER } }

    default:
      return state
  }
}

/* ─── Context ─── */
const AppContext = createContext(null)

export function AppProvider({ children }) {
  const [state, dispatch] = useReducer(appReducer, undefined, () => ({
    user: loadUser(),
  }))

  /* Persist user to localStorage on every change */
  useEffect(() => {
    storageSet(KEYS.USER, state.user)
  }, [state.user])

  /* ── Action creators ── */

  /** Add XP and handle level-up automatically */
  const addXp = useCallback(
    (amount) => dispatch({ type: ACTIONS.ADD_XP, payload: amount }),
    [],
  )

  /** Add coins */
  const addCoins = useCallback(
    (amount) => dispatch({ type: ACTIONS.ADD_COINS, payload: amount }),
    [],
  )

  /** Reset user to seed defaults and clear all storage */
  const reset = useCallback(() => {
    storageClear()
    dispatch({ type: ACTIONS.RESET })
  }, [])

  return (
    <AppContext.Provider value={{
      user:     state.user,
      dispatch,
      addXp,
      addCoins,
      reset,
    }}>
      {children}
    </AppContext.Provider>
  )
}

/** useApp — Access global state. Must be inside <AppProvider>. */
export function useApp() {
  const ctx = useContext(AppContext)
  if (!ctx) {
    throw new Error('[PrepXP] useApp() must be used inside <AppProvider>')
  }
  return ctx
}
