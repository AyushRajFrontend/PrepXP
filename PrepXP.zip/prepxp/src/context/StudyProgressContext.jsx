import { createContext, useContext, useCallback, useMemo } from 'react'
import { useLocalStorage }  from '@/hooks/useLocalStorage'
import { storageGet, KEYS } from '@/services/storage'
import { CHAPTERS }         from '@/data/chapters'

/**
 * StudyProgressContext — Shared lecture completion state.
 *
 * All components in the tree share ONE instance of this state,
 * so marking a lecture done in ChapterCard immediately updates
 * the progress bars on Home and Subjects too.
 *
 * Persists to localStorage under KEYS.PROGRESS.
 *
 * Shape in storage:
 *   {
 *     lectures: {
 *       [lectureId]: { done: true, doneAt: "ISO string" }
 *     }
 *   }
 */

/* ─── First-run seeder ───────────────────────────────────────────
   On the first app launch there's nothing in localStorage.
   We seed it with the lectures that are pre-marked done in the
   static chapters.js data file (demo progress for the showcase).
   On every subsequent launch this function returns early.
   ──────────────────────────────────────────────────────────────── */
function getInitialProgress() {
  const stored = storageGet(KEYS.PROGRESS)
  if (stored) return stored       /* Already seeded — use real data */

  /* Build the seed from chapters.js */
  const lectures = {}

  Object.values(CHAPTERS).flat().forEach(chapter => {
    chapter.lectures?.forEach(lecture => {
      if (lecture.done) {
        /* Mark with a plausible past date so "doneAt" looks real */
        lectures[lecture.id] = {
          done:   true,
          doneAt: '2026-08-01T08:00:00.000Z',
        }
      }
    })
  })

  return { lectures }
}

/* Computed once at module load — before any component mounts */
const SEEDED_PROGRESS = getInitialProgress()

/* Fallback for reset */
const EMPTY_PROGRESS = { lectures: {} }

/* ─── Context ─────────────────────────────────────────────────── */
const StudyProgressContext = createContext(null)

export function StudyProgressProvider({ children }) {
  const [progress, setProgress] = useLocalStorage(
    KEYS.PROGRESS,
    SEEDED_PROGRESS,
  )

  /* ── Read helpers ── */

  /** Returns true if the lecture with this ID has been marked done */
  const isLectureDone = useCallback(
    (lectureId) => progress.lectures?.[lectureId]?.done === true,
    [progress],
  )

  /** Count how many lectures in an array are done */
  const countDone = useCallback(
    (lectures = []) => lectures.filter(l => isLectureDone(l.id)).length,
    [isLectureDone],
  )

  /* ── Write helpers ── */

  /**
   * Mark a lecture done.
   *
   * @returns {boolean} true  — newly marked (caller should grant XP)
   *                    false — already done (caller should do nothing)
   */
  const markLectureDone = useCallback(
    (lectureId) => {
      /* Read current value synchronously before updating */
      if (progress.lectures?.[lectureId]?.done) return false

      setProgress(prev => ({
        ...prev,
        lectures: {
          ...prev.lectures,
          [lectureId]: { done: true, doneAt: new Date().toISOString() },
        },
      }))

      return true   /* Newly marked → caller should award XP */
    },
    [progress, setProgress],
  )

  /**
   * Wipe all stored lecture progress.
   * Called from Settings → "Reset All Progress".
   */
  const resetProgress = useCallback(
    () => setProgress(EMPTY_PROGRESS),
    [setProgress],
  )

  /* Memoize context value to prevent unnecessary child re-renders */
  const value = useMemo(
    () => ({ isLectureDone, countDone, markLectureDone, resetProgress }),
    [isLectureDone, countDone, markLectureDone, resetProgress],
  )

  return (
    <StudyProgressContext.Provider value={value}>
      {children}
    </StudyProgressContext.Provider>
  )
}

/**
 * useStudyProgress — Consume the shared lecture progress state.
 * Must be used inside <StudyProgressProvider>.
 */
export function useStudyProgress() {
  const ctx = useContext(StudyProgressContext)
  if (!ctx) {
    throw new Error('[PrepXP] useStudyProgress() must be used inside <StudyProgressProvider>')
  }
  return ctx
}
