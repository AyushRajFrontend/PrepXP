/**
 * subjects.js — Static seed data for development.
 *
 * Phase 3 (Subjects page) will move this into AppContext + localStorage
 * so progress persists across sessions. For now, components import
 * directly from here.
 *
 * Shape:
 *   id             — route param key (/subjects/:id)
 *   name           — display name
 *   tagline        — short description
 *   color          — Tailwind color token (maps to --color-* in @theme)
 *   accentVar      — raw CSS variable for inline styles
 *   progress       — 0-100 completion percentage
 *   doneChapters   — chapters completed
 *   totalChapters  — total chapters in syllabus
 *   doneLectures   — lectures watched
 *   totalLectures  — total lectures available
 */

export const SUBJECTS = [
  {
    id:            'physics',
    name:          'Physics',
    tagline:       'Mechanics, Optics & Electrostatics',
    color:         'physics',
    accentVar:     'var(--color-physics)',
    progress:      45,
    doneChapters:  32,
    totalChapters: 71,
    doneLectures:  312,
    totalLectures: 695,
  },
  {
    id:            'chemistry',
    name:          'Chemistry',
    tagline:       'Organic, Inorganic & Physical',
    color:         'chemistry',
    accentVar:     'var(--color-chemistry)',
    progress:      67,
    doneChapters:  48,
    totalChapters: 72,
    doneLectures:  411,
    totalLectures: 614,
  },
  {
    id:            'mathematics',
    name:          'Mathematics',
    tagline:       'Calculus, Algebra & Co-ordinate Geometry',
    color:         'math',
    accentVar:     'var(--color-math)',
    progress:      38,
    doneChapters:  27,
    totalChapters: 71,
    doneLectures:  285,
    totalLectures: 750,
  },
]

/** Overall completion across all subjects */
export const OVERALL_PROGRESS = Math.round(
  SUBJECTS.reduce((sum, s) => sum + s.progress, 0) / SUBJECTS.length,
)

/** Days until JEE Advanced 2027 (approximate) */
export const DAYS_TO_JEE = 287
