import { useState, useMemo }    from 'react'
import { motion }               from 'framer-motion'
import PageTransition           from '@/components/ui/PageTransition'
import GlassCard                from '@/components/ui/GlassCard'
import FilterTabs               from '@/components/ui/FilterTabs'
import SectionHeader            from '@/components/ui/SectionHeader'
import ActivityChart            from '@/components/charts/ActivityChart'
import XPChart                  from '@/components/charts/XPChart'
import SubjectDonut             from '@/components/charts/SubjectDonut'
import { PERIOD_CONFIG }        from '@/data/analytics'
import { useApp }               from '@/context/AppContext'
import { cn }                   from '@/utils/cn'

/**
 * Analytics — Study performance page.
 *
 * Sections (top → bottom):
 *   Period tabs     — 7 Days / 30 Days / All Time
 *   Study Activity  — area chart + 4 summary stats
 *   Breakdown row   — SubjectDonut (left) + XP summary (right)
 *   XP Earned       — bar chart
 */

const PERIOD_TABS = [
  { id: '7d',  label: '7 Days'   },
  { id: '30d', label: '30 Days'  },
  { id: 'all', label: 'All Time' },
]

/* ── Animation shorthand ── */
const fadeUp = (delay = 0) => ({
  initial:     { opacity: 0, y: 18 },
  whileInView: { opacity: 1, y: 0  },
  viewport:    { once: true, margin: '-40px' },
  transition:  { duration: 0.38, ease: [0.4, 0, 0.2, 1], delay },
})

/* ── Small summary stat cell ── */
function MiniStat({ label, value, sub }) {
  return (
    <div className="flex flex-col gap-0.5">
      <span className="text-[10px] text-mist">{label}</span>
      <span className="font-mono font-bold text-[16px] text-frost leading-none">
        {value}
      </span>
      {sub && (
        <span className="text-[10px] text-dim leading-none">{sub}</span>
      )}
    </div>
  )
}

export default function Analytics() {
  const { user }                = useApp()
  const [period, setPeriod]     = useState('7d')

  const { data, xKey } = PERIOD_CONFIG[period]

  /* Derive summary stats from current period data */
  const stats = useMemo(() => {
    const total    = data.reduce((s, d) => s + (d.lectures ?? 0), 0)
    const totalXP  = data.reduce((s, d) => s + (d.xp ?? 0), 0)
    const totalMin = data.reduce((s, d) => s + (d.minutes ?? 0), 0)
    const best     = data.reduce(
      (a, b) => (b.lectures ?? 0) > (a.lectures ?? 0) ? b : a,
      data[0] ?? {},
    )
    const activeDays = data.filter(d => (d.lectures ?? 0) > 0).length
    const avgLec     = data.length ? (total / data.length).toFixed(1) : '0'
    const hours      = Math.floor(totalMin / 60)
    const mins       = totalMin % 60
    const timeStr    = hours > 0 ? `${hours}h ${mins}m` : `${mins}m`

    return { total, totalXP, totalMin, timeStr, best, activeDays, avgLec }
  }, [data])

  const periodWord = period === '7d' ? 'week' : period === '30d' ? 'month' : 'time'

  return (
    <PageTransition>
      <div className="px-4 pb-10 space-y-5">

        {/* ── Page header ── */}
        <motion.div
          className="pt-5"
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.35, ease: [0.4, 0, 0.2, 1] }}
        >
          <h1 className="font-display font-bold text-[26px] text-frost">
            Analytics
          </h1>
          <p className="text-[13px] text-mist mt-0.5">
            Track your study performance
          </p>
        </motion.div>

        {/* ── Period selector ── */}
        <FilterTabs
          tabs={PERIOD_TABS}
          active={period}
          onChange={setPeriod}
        />

        {/* ── Study Activity ── */}
        <motion.section {...fadeUp(0.05)}>
          <SectionHeader title="Study Activity" />
          <GlassCard noPadding className="p-4 pt-4 pb-2">
            {/* 4 summary stats */}
            <div className="grid grid-cols-4 gap-2 mb-4">
              <MiniStat
                label="Lectures"
                value={stats.total}
                sub={`this ${periodWord}`}
              />
              <MiniStat
                label="Avg / session"
                value={stats.avgLec}
              />
              <MiniStat
                label="Best session"
                value={stats.best?.[xKey] ?? '—'}
                sub={`${stats.best?.lectures ?? 0} lec`}
              />
              <MiniStat
                label="Active"
                value={`${stats.activeDays}/${data.length}`}
                sub="sessions"
              />
            </div>

            {/* Area chart */}
            <ActivityChart data={data} xKey={xKey} />
          </GlassCard>
        </motion.section>

        {/* ── Breakdown row: Donut + XP summary ── */}
        <motion.section {...fadeUp(0.07)}>
          <div className="grid grid-cols-2 gap-3">

            {/* Subject completion donut */}
            <GlassCard noPadding className="p-4">
              <p className="text-[10.5px] font-bold text-mist uppercase
                            tracking-[0.08em] mb-3">
                By Subject
              </p>
              <SubjectDonut />
            </GlassCard>

            {/* XP summary + study time */}
            <GlassCard noPadding className="p-4 flex flex-col justify-between">
              <div>
                <p className="text-[10.5px] font-bold text-mist uppercase
                              tracking-[0.08em] mb-3">
                  XP This {periodWord.charAt(0).toUpperCase() + periodWord.slice(1)}
                </p>
                <span className="font-mono font-bold text-[26px] text-gradient-brand
                                 block leading-none">
                  {stats.totalXP.toLocaleString()}
                </span>
                <span className="text-[11px] text-mist mt-1 block">XP earned</span>
              </div>

              <div className="mt-4 pt-4 border-t border-white/[0.05]">
                <p className="text-[10.5px] font-bold text-mist uppercase
                              tracking-[0.08em] mb-2">
                  Study Time
                </p>
                <span className="font-mono font-bold text-[20px] text-frost leading-none">
                  {stats.timeStr}
                </span>
                <span className="text-[11px] text-mist block mt-0.5">
                  total study time
                </span>
              </div>

              <div className="mt-3 pt-3 border-t border-white/[0.05]">
                <p className="text-[10.5px] font-bold text-mist uppercase
                              tracking-[0.08em] mb-1">
                  Current Level
                </p>
                <div className="flex items-baseline gap-1.5">
                  <span className="font-mono font-bold text-[22px] text-purple leading-none">
                    {user.level}
                  </span>
                  <span className="text-[11px] text-mist">
                    · {user.xp.toLocaleString()} XP
                  </span>
                </div>
              </div>
            </GlassCard>

          </div>
        </motion.section>

        {/* ── XP Earned bar chart ── */}
        <motion.section {...fadeUp(0.09)}>
          <SectionHeader title="XP Earned" />
          <GlassCard noPadding className="p-4 pb-2">
            {/* Highlight note */}
            <p className="text-[11px] text-mist mb-3">
              <span
                className="inline-block w-2 h-2 rounded-sm mr-1.5"
                style={{ background: '#C084FC', verticalAlign: 'middle' }}
              />
              Highlighted bar = most recent session
            </p>
            <XPChart data={data} xKey={xKey} />
          </GlassCard>
        </motion.section>

      </div>
    </PageTransition>
  )
}
