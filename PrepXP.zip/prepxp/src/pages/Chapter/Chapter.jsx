import { useState, useMemo }              from 'react'
import { useParams, Navigate }            from 'react-router-dom'
import { AnimatePresence, motion }        from 'framer-motion'
import { SearchX }                        from 'lucide-react'
import PageTransition                     from '@/components/ui/PageTransition'
import SearchBar                          from '@/components/ui/SearchBar'
import FilterTabs                         from '@/components/ui/FilterTabs'
import ChapterCard                        from '@/components/cards/ChapterCard'
import ChapterHeader                      from './ChapterHeader'
import { SUBJECTS }                       from '@/data/subjects'
import { CHAPTERS }                       from '@/data/chapters'

/**
 * Chapter — Chapter list page.
 *
 * Route: /subjects/:id  (e.g. /subjects/physics)
 *
 * Features:
 *   - ChapterHeader: subject info, progress bar, status chips
 *   - Live search: filter chapters by name
 *   - FilterTabs: All / Done / In Progress / Not Started
 *   - Expandable ChapterCards: tap to reveal inline lecture list
 *   - Only one chapter expanded at a time
 *   - Empty state with clear-filter action
 *
 * If subject ID is not found → redirect to /subjects
 */

/* ─── Filter tab definitions ─── */
const BASE_TABS = [
  { id: 'all',         label: 'All'          },
  { id: 'completed',   label: 'Done'         },
  { id: 'in-progress', label: 'In Progress'  },
  { id: 'not-started', label: 'Not Started'  },
]

const FILTER_FN = {
  'all':         ()  => true,
  'completed':   (c) => c.status === 'completed',
  'in-progress': (c) => c.status === 'in-progress',
  'not-started': (c) => c.status === 'not-started',
}

export default function Chapter() {
  const { id }   = useParams()
  const subject  = SUBJECTS.find(s => s.id === id)
  const chapters = CHAPTERS[id] ?? []

  /* ── State ── */
  const [search,     setSearch]     = useState('')
  const [filter,     setFilter]     = useState('all')
  const [expandedId, setExpandedId] = useState(null)

  /* ── Guard: unknown subject → back to subjects list ── */
  if (!subject) {
    return <Navigate to="/subjects" replace />
  }

  /* ── Filter + search ── */
  const visible = useMemo(() => {
    const q  = search.trim().toLowerCase()
    const fn = FILTER_FN[filter] ?? FILTER_FN.all

    return chapters.filter(c =>
      fn(c) && (q === '' || c.name.toLowerCase().includes(q)),
    )
  }, [chapters, search, filter])

  /* ── Tabs with live counts ── */
  const tabs = useMemo(() =>
    BASE_TABS.map(t => ({
      ...t,
      count: t.id === 'all'
        ? undefined
        : chapters.filter(FILTER_FN[t.id]).length,
    })),
  [chapters])

  /* ── Toggle chapter expand (accordion: one at a time) ── */
  const toggleChapter = (chapterId) => {
    setExpandedId(prev => prev === chapterId ? null : chapterId)
  }

  const hasResults  = visible.length > 0
  const isFiltering = search !== '' || filter !== 'all'

  return (
    <PageTransition>
      <div className="px-4 pb-10">

        {/* ── Subject header ── */}
        <ChapterHeader subject={subject} chapters={chapters} />

        {/* ── Divider ── */}
        <div className="my-5 border-t border-white/[0.05]" />

        {/* ── Search ── */}
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, ease: [0.4, 0, 0.2, 1], delay: 0.15 }}
        >
          <SearchBar
            value={search}
            onChange={(val) => {
              setSearch(val)
              /* Collapse open chapter when search changes */
              setExpandedId(null)
            }}
            placeholder={`Search ${subject.name} chapters…`}
            className="mb-3"
          />
        </motion.div>

        {/* ── Filter tabs ── */}
        <motion.div
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.28, ease: [0.4, 0, 0.2, 1], delay: 0.20 }}
        >
          <FilterTabs
            tabs={tabs}
            active={filter}
            onChange={(val) => {
              setFilter(val)
              setExpandedId(null)
            }}
            className="mb-5"
          />
        </motion.div>

        {/* ── Results count ── */}
        {isFiltering && hasResults && (
          <p className="text-[12px] text-dim mb-3">
            {visible.length} chapter{visible.length !== 1 ? 's' : ''} found
          </p>
        )}

        {/* ── Chapter list / Empty state ── */}
        <AnimatePresence mode="wait">
          {hasResults ? (
            <motion.div
              key="list"
              className="space-y-3"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.18 }}
            >
              {visible.map((chapter, i) => (
                <motion.div
                  key={chapter.id}
                  initial={{ opacity: 0, y: 16 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{
                    duration: 0.35,
                    ease:     [0.4, 0, 0.2, 1],
                    delay:    0.22 + i * 0.05,
                  }}
                >
                  <ChapterCard
                    chapter={chapter}
                    subjectColor={subject.color}
                    isExpanded={expandedId === chapter.id}
                    onToggle={() => toggleChapter(chapter.id)}
                  />
                </motion.div>
              ))}

              {/* "Showing X of Y" footnote */}
              {!isFiltering && chapters.length > 0 && (
                <p className="text-center text-[11px] text-dim pt-2 pb-1">
                  Showing {chapters.length} of {subject.totalChapters} chapters
                </p>
              )}
            </motion.div>
          ) : (
            /* ── Empty state ── */
            <motion.div
              key="empty"
              className="flex flex-col items-center justify-center py-20 text-center"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.25, ease: 'easeOut' }}
            >
              <SearchX size={40} className="text-dim mb-4" strokeWidth={1.4} />
              <p className="text-[15px] font-semibold text-snow mb-1">
                No chapters found
              </p>
              <p className="text-[13px] text-mist mb-5">
                {search
                  ? `No results for "${search}"`
                  : 'No chapters match this filter'}
              </p>
              {isFiltering && (
                <button
                  onClick={() => { setSearch(''); setFilter('all') }}
                  className="text-[13px] font-semibold text-purple
                             px-5 py-2.5 rounded-xl
                             bg-purple/10 border border-purple/20
                             active:scale-95 transition-transform duration-150"
                >
                  Clear filters
                </button>
              )}
            </motion.div>
          )}
        </AnimatePresence>

      </div>
    </PageTransition>
  )
}
