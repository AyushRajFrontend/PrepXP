import { motion }             from 'framer-motion'
import { Link }               from 'react-router-dom'
import { ChevronRight }       from 'lucide-react'
import PageTransition         from '@/components/ui/PageTransition'
import HomeHeader             from './HomeHeader'
import XPCard                 from '@/components/cards/XPCard'
import StreakCard             from '@/components/cards/StreakCard'
import TodayGoalCard         from '@/components/cards/TodayGoalCard'
import SubjectProgressCard   from '@/components/cards/SubjectProgressCard'
import MissionCard           from '@/components/cards/MissionCard'
import StatsCard             from '@/components/cards/StatsCard'
import { useApp }            from '@/context/AppContext'
import { SUBJECTS }          from '@/data/subjects'
import { DAILY_MISSIONS }    from '@/data/missions'

/**
 * Home — Main dashboard page.
 *
 * Layout (top → bottom):
 *   HomeHeader        — greeting + date + notification bell
 *   XPCard            — hero: level, XP bar, coins, rank
 *   [StreakCard | TodayGoalCard]  — 2-column row
 *   Subject Progress  — 3 SubjectProgressCards
 *   Daily Missions    — MissionCard list
 *   Quick Stats       — 2x2 StatsCard grid
 *
 * All cards animate in using whileInView (once per session).
 * The XPCard uses a slightly shorter delay since it's always
 * in view on load.
 */

/* ── Reusable fade-up motion props ── */
const FADE_UP = {
  initial:  { opacity: 0, y: 18 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: '-50px' },
}

const fadeUp = (delay = 0) => ({
  ...FADE_UP,
  transition: { duration: 0.4, ease: [0.4, 0, 0.2, 1], delay },
})

/* ── Section header: title + optional "See all" link ── */
function SectionHeader({ title, linkTo }) {
  return (
    <div className="flex items-center justify-between mb-3">
      <h2 className="font-display font-bold text-[17px] text-frost">
        {title}
      </h2>
      {linkTo && (
        <Link
          to={linkTo}
          className="flex items-center gap-0.5 text-[13px] text-purple font-semibold
                     active:opacity-70 transition-opacity"
        >
          See all
          <ChevronRight size={14} strokeWidth={2.5} />
        </Link>
      )}
    </div>
  )
}

export default function Home() {
  const { user } = useApp()

  return (
    <PageTransition>
      <div className="px-4 pb-8 space-y-5">

        {/* ── Greeting header ── */}
        <HomeHeader user={user} />

        {/* ── Hero XP card ── */}
        <motion.div {...fadeUp(0.05)}>
          <XPCard user={user} />
        </motion.div>

        {/* ── 2-col: Streak + Today's Goal ── */}
        <div className="grid grid-cols-2 gap-3">
          <motion.div {...fadeUp(0.10)} className="flex">
            <StreakCard streak={user.streak} />
          </motion.div>
          <motion.div {...fadeUp(0.15)} className="flex">
            <TodayGoalCard done={5} total={8} />
          </motion.div>
        </div>

        {/* ── Subject Progress ── */}
        <motion.section {...fadeUp(0.20)}>
          <SectionHeader title="Subjects" linkTo="/subjects" />
          <div className="space-y-3">
            {SUBJECTS.map(subject => (
              <SubjectProgressCard key={subject.id} subject={subject} />
            ))}
          </div>
        </motion.section>

        {/* ── Daily Missions ── */}
        <motion.section {...fadeUp(0.05)}>
          <SectionHeader title="Daily Missions" />
          <MissionCard missions={DAILY_MISSIONS} />
        </motion.section>

        {/* ── Quick Stats ── */}
        <motion.section {...fadeUp(0.05)}>
          <SectionHeader title="Quick Stats" />
          <StatsCard user={user} />
        </motion.section>

      </div>
    </PageTransition>
  )
}
